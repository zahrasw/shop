This is a shopping website where you can see clothes, accessories, bags and other items.  A website that is made of two pages and most of them are HTML and CSSThis is a shopping website where you can see clothes, accessories, bags and other items.  A website that is made of two pages and most of them are HTML and CSS


html
   